#### Knowledge Discovery and Data Mining (CS 513A)####


# Course  : CS 513 - A
# First Name : Rachi
# Last Name : Rana
#Id : 10455300
# Purpose : midterm question 6

####### *************************************************** ########

# clearing object enviroment 
rm(list=ls());


Bayes_adult <- read.csv("~/Desktop/adult_income_Bayes.csv",
           na.strings = "",
           colClasses=c("Workclass"="factor","Education"="factor","Marital_status"="factor",
                        "Occupation"="factor","Relationship"="factor","race"="factor",
                        "Gender"="factor","Native_country"="factor","Income"="factor"))
View(Bayes_adult)
#	Remove any row with missing values
Bayes_adult<-na.omit(Bayes_adult) 

# Create index every third record
index <- seq(1,nrow(Bayes_adult),by=5) 

#Create test data set
test<-Bayes_adult[index,] 

#Create training data set
training <-Bayes_adult[-index,] 

library(e1071)
#train
nBayes_train <- naiveBayes(factor(Income)~., data=training[,c("Workclass","Education","Marital_status","Occupation","Relationship","race",
                                                              "Gender","Native_country","Income")])
#predict
predict_NB<-predict(nBayes_train,test[,c("Workclass","Education","Marital_status","Occupation","Relationship","race",
                                         "Gender","Native_country","Income")])
table(NBayes_all=predict_NB,Income=test$Income)
#Income
#NBayes_all  <=50K  >50K
#<=50K   3982   443
#>50K     905  1183

# Error rate
NB_error_rate<-sum(predict_NB!=test$Income)/length(predict_NB)
NB_error_rate
#[1] 0.2069707
