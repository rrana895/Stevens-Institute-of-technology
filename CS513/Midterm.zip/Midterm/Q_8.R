#### Knowledge Discovery and Data Mining (CS 513A)####


# Course  : CS 513 - A
# First Name : Rachi
# Last Name : Rana
#Id : 10455300
# Purpose : midterm question 8

####### *************************************************** ########

# clearing object enviroment 
rm(list=ls());


dtree_data <- 
  adult_Dtree <- read.csv("~/Desktop/adult_income_Dtree.csv",
           na.strings = "",
           colClasses=c("Age"="factor","Workclass"="factor","Education"="factor",
                        "Marital_status"="factor","Occupation"="factor","Relationship"="factor",
                        "race"="factor","Gender"="factor","Hours_worked_Perweek"="factor",
                        "Native_country"="factor","Income"="factor"))
View(adult_Dtree)
# Create index every third record
index <- seq(1,nrow(dtree_data),by=5) 

#Create test data set
test<-dtree_data[index,] 

#Create training data set
training <-dtree_data[-index,] 

library('C50')
dtree_train<-C5.0(factor(Income)~.,data=training)


predtree<-predict(dtree_train,newdata=test)
table(dtree_all=predtree,Income=test$Income)
#Income
#dtree_all  <=50K  >50K
#<=50K   4520   677
#>50K     367   949

# Error rate
dtree_error_rate<-sum(predtree!=test$Income)/length(predtree)
dtree_error_rate
#[1] 0.1602948