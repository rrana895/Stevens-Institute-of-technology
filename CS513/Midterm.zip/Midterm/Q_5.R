#### Knowledge Discovery and Data Mining (CS 513A)####


# Course  : CS 513 - A
# First Name : Rachi
# Last Name : Rana
#Id : 10455300
# Purpose : midterm question 5

####### *************************************************** ########

# clearing object enviroment 
rm(list=ls());


#load adult_income_knn
knn_adult<- read.csv("~/Desktop/adult_income_knn.csv",  na.strings = "",
                 colClasses=c("Age"="factor","Education_Years"="factor","Gender"="factor",
                              "Hours_worked_Perweek"="factor","Income"="factor")) 
View(knn_adult)

#	Remove any row with missing values
knn_adult<-na.omit(knn_adult) 

# create index every third record
index <- seq(1,nrow(knn_adult),by=5) 

#create test data set
test<-knn_adult[index,] 

#create training data set
training <-knn_adult[-index,] 

library(kknn)

#k = 1
#predict
predict_knn <- kknn(formula=factor(Income)~. ,  training[,],test[,]  , kernel="rectangular", k=1)

fit <- fitted(predict_knn)
table(kknn=fit,test$Income)
#kknn      <=50K  >50K
#<=50K   4074   933
#>50K     813   693

# Error rate
knn_error_rate=sum(fit!=test$Income)/length(test$Income)
knn_error_rate
#[1] 0.2680792

#k = 3
predict_knn <- kknn(formula=factor(Income)~. ,  training[,],test[,]  , kernel="rectangular", k=3)#predict

fit <- fitted(predict_knn)
table(kknn=fit,test$Income)
#kknn      <=50K  >50K
#<=50K   4372   973
#>50K     515   653

# Error rate
knn_error_rate=sum(fit!=test$Income)/length(test$Income)
knn_error_rate
#[1] 0.2284661

#k = 5
predict_knn <- kknn(formula=factor(Income)~. ,  training[,],test[,]  , kernel="rectangular", k=5)#predict

fit <- fitted(predict_knn)
table(kknn=fit,test$Income)
#kknn      <=50K  >50K
#<=50K   4413   969
#>50K     474   657

# Error rate
knn_error_rate=sum(fit!=test$Income)/length(test$Income)
knn_error_rate
#[1] 0.2215569
