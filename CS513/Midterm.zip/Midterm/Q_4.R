#### Knowledge Discovery and Data Mining (CS 513A)####
# Assignment 2 -breast-cancer-wisconsin.data #

# Course  : CS 513 - A
# First Name : Rachi
# Last Name : Rana
#Id : 10455300
# Purpose : midterm question 4

####### *************************************************** ########

# clearing object enviroment 
rm(list=ls());


#load adult_income_EDA
adult<- read.csv("~/Desktop/adult_income_EDA.csv", na.strings = c("?"))
View(adult)

# (min, max, mean,median, standard deviation )
cat("Mean of column Age: ", mean(adult[["Age"]]) ,"Standard deviation of column Age:", sd(adult[["Age"]]), "Median of the column Age:",median(adult[["Age"]]),"Min of column Age: ", min(adult[["Age"]]), "Max of column Age: ", max(adult[["Age"]])) 
cat("Mean of column Education_Years: ", mean(adult[["Education_Years"]]) ,"Standard deviation of column Education_Years:", sd(adult[["Education_Years"]]), "Median of the column Education_Years:",median(adult[["Education_Years"]]),"Min of column Education_Years: ", min(adult[["Education_Years"]]), "Max of column Education Years: ", max(adult[["Education_Years"]])) 
cat("Mean of column Hours_worked_Perweek: ", mean(adult[["Hours_worked_Perweek"]]) ,"Standard deviation of column Hours_worked_Perweek:", sd(adult[["Hours_worked_Perweek"]]), "Median of the column Hours_worked_Perweek:",median(adult[["Hours_worked_Perweek"]]),"Min of column Hours_worked_Perweek: ", min(adult[["Hours_worked_Perweek"]]), "Max of column Hours_worked_Perweek: ", max(adult[["Hours_worked_Perweek"]]))

# Identifying missing values

as.data.frame(sapply(adult,sub,pattern='\\?',replacement=NA)) #replace all the question marks with NA
adult[is.na(adult)]
is.na(adult)

# Replacing the missing values with the "median" of the column.
adult$Age[which(is.na(adult$Age))]<- median(adult$Age,na.rm = TRUE)
adult$Education_Years[which(is.na(adult$Education_Years))]<- median(adult$Education_Years,na.rm = TRUE)
adult$Hours_worked_Perweek[which(is.na(adult$Hours_worked_Perweek))]<- median(adult$Hours_worked_Perweek,na.rm = TRUE)
View(adult)

#Develop a box plot for the numeric variables 
boxplot(adult$Age, ylab='Age')
boxplot(adult$Education_Years, ylab="Education_Years")
boxplot(adult$Hours_worked_Perweek, ylab='Hours_worked_Perweek')
