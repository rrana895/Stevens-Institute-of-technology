#### Knowledge Discovery and Data Mining (CS 513A)####

# Course  : CS 513 - A
# First Name : Rachi
# Last Name : Rana
#Id : 10455300
# Purpose : Assignment 09: Clusters

#######H-Clust##############
rm(list=ls())

cancer<-read.csv("~/Desktop/wisc_bc_ContinuousVar.csv",na.strings = '?')
#To factor the data set

cancer<-na.omit(cancer)
cancer<-cancer[-1]
cancer_dist<-dist(cancer[,-1])
hclust_results<-hclust(cancer_dist)
plot(hclust_results)
hclust_2<-cutree(hclust_results,2)
table(hclust_2,cancer[,1])
#hclust_2   B   M
#1 357 192
#2   0  20
#########K-Means########################
rm(list=ls())
cancer<-read.csv("~/Desktop/wisc_bc_ContinuousVar.csv",na.strings = '?')
View(cancer)
summary(cancer)
table(cancer$diagnosis)
#B   M 
#357 212 

#To factor the data set
cancer<-na.omit(cancer)
cancer<-cancer[-1]
kmeans_2<- kmeans(cancer[,-1],2,nstart = 10)
kmeans_2$cluster
table(kmeans_2$cluster,cancer[,1])
##B   M
#1   1 130
#2 356  82