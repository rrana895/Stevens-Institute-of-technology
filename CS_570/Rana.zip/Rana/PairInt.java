package Maze;

public class PairInt {
	
	private int x; //Data fields
    private int y;

    public PairInt(int x, int y) {// constructor
       
    	this.x = x;
        this.y = y;
    }
 
    
    public int getX() { //return int return the x
        
    	return x;
    }
    
    
    public int getY() { // return y
        
    	return y;
    }

    
    public void setX(int x) { // x to set
        
    	this.x = x;
    }
    
    
    public void setY(int y) { // y to set
        
    	this.y = y;
    }

    
    public boolean equals(Object p) { // if the parameter object is equal to PairInt
    	if (p instanceof PairInt) {
    		
    		PairInt compare = (PairInt) p;
    		boolean analysis = compare.getX() == this.getX() && compare.getY() == this.getY();
			return analysis;
		}
		
    	return false;
	}
    

    public String toString() { // string representation
        
    	return "(" + x + "," + y + ")";
    }

    
    public PairInt copy() { // copy of PairInt
    	
    	return new PairInt(x, y);
    
    }
}
