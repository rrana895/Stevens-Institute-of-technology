package midterm_project;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.Test;
import midterm_project.PostfixEvaluator;

public class PostfixEvaluatorTest {

	@Test
	public void simpleExpressionWithSamePrecedenceAdd() throws Exception {
		String infix = "2+4";
		String expectedR = "2 4 + ";
		PostfixEvaluator postFixConverter = new PostfixEvaluator();
	    String result = postFixConverter.convert(infix);
	    
	    assertEquals(expectedR, result);
	}	

	@Test
	public void simpleExpressionEvaluateAdd() throws Exception {
		String postfix = "2 4 + ";
		Double expectedR = (double) 6;
		
		PostfixEvaluator evaluate = new PostfixEvaluator();
		Double result = evaluate.eval(postfix);
		
		assertEquals(expectedR, result);
	}
	
	@Test
	public void simpleExpressionSub() throws Exception {
		String infix = "5-2";
		String expectedR = "5 2 - ";
		
		PostfixEvaluator postFixConverter = new PostfixEvaluator();
	    String result = postFixConverter.convert(infix);
	    
	    assertEquals(expectedR, result);
	}
	
	@Test
	public void simpleExpressionEvaluateSub() throws Exception {
		String postfix = "5 2 - ";
		Double expectedR = (double) 3;
		
		PostfixEvaluator evaluate = new PostfixEvaluator();
		Double result = evaluate.eval(postfix);
		
		assertEquals(expectedR, result);
	}
	
	@Test
	public void simpleExpressionMixedPrecedence() throws Exception {
		String infix = "4-2/2*3+2^2";
		String expectedR = "4 2 2 / 3 * - 2 2 ^ + ";
		
		PostfixEvaluator postFixConverter = new PostfixEvaluator();
	    String result = postFixConverter.convert(infix);
	    
	    assertEquals(expectedR, result);	
	}
	
	@Test
	public void simpleExpressionMixedPrecedenceEvaluate() throws Exception {
		String postfix = "4 2 2 / 3 * - 2 2 ^ + ";
		Double expectedR = (double) 5.0;
		
		PostfixEvaluator evaluate = new PostfixEvaluator();
		Double result = evaluate.eval(postfix);
		
		assertEquals(expectedR, result);
	}
	
	@Test
	public void ExpressionMixedPrecedenceParenthesis() throws Exception {
		String infix ="5-2+(4*3)-(2^2)+6/2";
		String expectedR = "5 2 - 4 3 * + 2 2 ^ - 6 2 / + ";
		
		PostfixEvaluator postFixConverter = new PostfixEvaluator();
	    String result = postFixConverter.convert(infix);
	    
	    assertEquals(expectedR, result);
	}
	
	@Test
	public void ExpressionMixedPrecedenceParenthesisEvaluate() throws Exception {
		String postfix = "5 2 - 4 3 * + 2 2 ^ - 6 2 / + ";
		Double expectedR = (double) 14.0;
		
		PostfixEvaluator evaluate = new PostfixEvaluator();
		Double result = evaluate.eval(postfix);
		
		assertEquals(expectedR, result);
	}
	
	@Test 
	public void expressionWithInvalidOperator() throws Exception {
		String infix = "1&2";
		String expectedR = "1 2 ";
		
		PostfixEvaluator postFixConverter = new PostfixEvaluator();
	    String result = postFixConverter.convert(infix);
	    
	    assertEquals(expectedR, result);	
	}
	
	@Test(expected = PostfixEvaluator.SyntaxErrorException.class)
	public void expressionWithInvalidOperatorEvaluate() throws Exception {
		String postfix = "1 2 ";
		String expectedR ="Syntax Error: No such element ";
		
		PostfixEvaluator evaluate = new PostfixEvaluator();
		Double result = evaluate.eval(postfix);
		
		assertEquals(expectedR, result);	
	}
	
	@Test 
	public void longerExpressionWithExponent() throws Exception {
		String infix = "10.2*(8-6)/3+112.5+2^4";
		String expectedR ="10.2 8 6 - * 3 / 112.5 + 2 4 ^ + ";
		
		PostfixEvaluator postFixConverter = new PostfixEvaluator();
	    String result = postFixConverter.convert(infix);
	    
	    assertEquals(expectedR, result);	
			
	}
	
	@Test
	public void longerExpressionWithExponentEvaluate() throws Exception {
		String postfix = "10.2 8 6 - * 3 / 112.5 + 2 4 ^ + ";
		Double expectedR = (double)135.3;
		
		PostfixEvaluator evaluate = new PostfixEvaluator();
		Double result = evaluate.eval(postfix);
		
		assertEquals(expectedR, result);
	}
	
	@Test(expected = PostfixEvaluator.SyntaxErrorException.class)
	public void parenthesisUnexpected() throws Exception {
		String infix ="(10+2";
		String expectedR ="Unmatched opening parenthesis ";
		

		PostfixEvaluator postFixConverter = new PostfixEvaluator();
	    String result = postFixConverter.convert(infix);
	    
	    
	    assertEquals(expectedR, result);		
	}
	
	@Test
	public void ExponentWithDecimal() throws Exception {
		String postfix ="2 4.5 ^";
		//boolean expectedR = false;
		
		boolean result = PostfixEvaluator.isValid(postfix);
		System.out.println("Result is it vaild exponent? : "+result);
		
		assertEquals(false, result);
		
	}
	
}


