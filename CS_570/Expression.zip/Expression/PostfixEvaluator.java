package midterm_project;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.EmptyStackException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.regex.Pattern;
import java.util.Scanner;

public class PostfixEvaluator {
	
	public static class SyntaxErrorException extends Exception { // To report Syntax Error
			SyntaxErrorException(String message) {
	            super(message);
		}
	}
	
	// Data Fields	
	private Stack<Character> operatorStack; // stack of characters
		
	private static final String OPERATORS = "-+*/^()"; // OPERATORS
	private static final int[] PRECEDENCE = {1, 1, 2, 2, 3, -1, -1}; // precedence of the operators, matches order of OPERATORS
	
	//Patterns to extract tokens, token either string of digits or operator
	private static final String PATTERN = "\\d+\\.\\d*|\\d+|" + "\\p{L}[\\p{L}\\p{N}]*" + "|[" + OPERATORS + "]"; 
		
	private StringBuilder postfix; // postfix Strings
	
		
	//Convert from infix to postfix
	
	public String convert(String infix) throws SyntaxErrorException {
		operatorStack = new Stack<Character>();
		postfix = new StringBuilder();
		Scanner scan = new Scanner(infix);
			
		try { //process each token in the infix 
			
			String nextToken;
			while ((nextToken = scan.findInLine(PATTERN)) != null) {
				char firstChar = nextToken.charAt(0);
				
				// is it an operand then	
				if (Character.isLetter(firstChar) || Character.isDigit(firstChar)) {
					postfix.append(nextToken);
					postfix.append(' ');
				}
				// is it an operator then	
				else if(isOperator(firstChar)) {     
					processOperator(firstChar);
				} 
				else {		
					throw new SyntaxErrorException("Unexpected Character Encountered: "+ firstChar); 
				}
			}
			// pop any operators and append them to postfix
			while (!operatorStack.isEmpty()) {
				char op = operatorStack.pop();
				// Any '(' is not mismatched 
				if(op == '(') {
					throw new SyntaxErrorException("Unmatched opening parenthesis");
				}
				postfix.append(op);
				postfix.append(' ');		
			} 
			// stack is empty
			return postfix.toString();
				
			} catch(EmptyStackException ex) {
				throw new SyntaxErrorException("Syntax Error: The stack is empty");
			}		
	 }
	      	        
	// Method to process operators op The operator 
	
	 private void processOperator(char op) {
		if (operatorStack.isEmpty() || op == '(') { 
			operatorStack.push(op);
		}
		else { // Peek the operator stack and let topOp be the top operator
			char topOp = operatorStack.peek();	 
				 if (precedence(op) > precedence(topOp)) {
					 operatorStack.push(op);
					 
				 }else { // pop all the stacks with higher or equal precedence than op
					 while (!operatorStack.isEmpty() && precedence(op) <= precedence(topOp)) { 
					 	 operatorStack.pop();
					 	 if (topOp == '(') { // Matching '(' popped ‐ exit loop
					 		break;
					 	 }
					 	postfix.append(topOp);
					 	postfix.append(' ');
					 	
					 	if (!operatorStack.isEmpty()) { // Reset topOp	
					 		topOp = operatorStack.peek();
					 	}
					 }
					 // assert: Operator stack is empty or
					 // current operator precedence >
					 // top of stack operator precedence.
					 if (op != ')') {
					 	operatorStack.push(op);
					}
				 }
			}
	 }
				
	 // The operators to evaluate postfix expression
	
	  private static double evalOp(char op, Deque<Double> operandStack) {
		 double rhs = operandStack.pop();
		 double lhs = operandStack.pop();
		 double result = 0;
				
		//Evaluate the operator		
		 switch(op) {
			case '+' : result = lhs + rhs; // for addition
					   break;
			case '-' : result = lhs - rhs; // for subtraction
					   break;
							
			case '/' : result = lhs / rhs; // for division
					   break;
							
			case '*' : result = lhs * rhs; // for multiplication
					   break;
							
			case '^' :	result = pow(lhs, (int) rhs); // for exponent
						break;
		}
		return result;
	 }
			
	  private static double pow(double lhs, int rhs) { // To calculate the exponent of a number while multiplying itself
		 double result = 1;	
			for(int i =1; i<=rhs; i++) {
				result = result * lhs;
			}
		return result;
	  }
			
	 
	// Evaluate postfix expression	
	 public static double eval(String expression) throws SyntaxErrorException {
		Deque<Double> operandStack = new ArrayDeque<>();
		//Process token
		String[] tokens = expression.split("\\s+"); // space is taken to evaluate the each tokens into the stack
			try {
				for (String nextToken : tokens) {
					char firstChar = nextToken.charAt(0);  // first character  
		
					if(Character.isDigit(firstChar)) { // if the characters are digits
						double value = Double.parseDouble(nextToken);
						operandStack.push(value);	
						//System.out.println(value);
						
					}else if (isOperator(firstChar)) { // if it is an operator
						double result = evalOp(firstChar, operandStack);
						operandStack.push(result);
						//System.out.println(result);	
					}else {
						throw new SyntaxErrorException("Invalid character encountered: "); // when the character is not valid
						}
					}
				double answer = operandStack.pop();
				
				if (operandStack.isEmpty()) {
					return answer;
				}else {
					throw new SyntaxErrorException("Syntax Error: No such element "); // ill formed expression for evaluation throws errror
				}
			}catch (NoSuchElementException ex) {
				throw new SyntaxErrorException("Syntax Error: No such element "); // ill formed expression for evaluation throws errror
	 		}
	 } 
		
	
	 private static boolean isOperator(char ch) { // character is an operator	
		return OPERATORS.indexOf(ch) != -1; // ch character to be tested
	 }
		
	 private static int precedence(char op) { // precedence of an operator
		return PRECEDENCE[OPERATORS.indexOf(op)] ; // op the Operator
	 }
	
	 public static boolean isValid(String input) { // To check if the digit after the ^ operator is decimal or not. 
		String[] tokens = input.split("\\s+");
		for(int i=0;i<tokens.length; i++) {
			char firstChar = tokens[i].charAt(0);
			if (firstChar == '^') {
				
				if ((i>0) && (hasDecimal(tokens[i-1]))) {
					return false;
				}
			}
		}
		return true;
	 }
	
	 private static boolean hasDecimal(String input) { // Check if the digit after ^ operator has a Decimal "." or not.
		boolean hasDecimal = false;
		if(input.contains(".")) {
			hasDecimal = true;
		}
		return hasDecimal;
	 }
		
	 public static void main(String[] args) throws IOException, SyntaxErrorException {	// Main function	
		
		String infix;	
	    BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); // Takes the an expression in infix 
	    System.out.print("Enter infix expression: ");
	    infix = br.readLine();
	        
	        
		PostfixEvaluator postFixEvaluator = new PostfixEvaluator();
	    String output = postFixEvaluator.convert(infix); // converts the entered expression to postfix 
	    boolean isValid = isValid(output);
	    if (!isValid) {										// checking if the digit is valid or not for exponent
	    	System.err.println("Input error with ^ operator having decimal");
	    	System.exit(1);
	    }
	    System.out.println("Postfix Output:" + output); // if the expression is valid print the postfix expression for evaluation
	        
	    PostfixEvaluator evaluate = new PostfixEvaluator(); 
	    double op = evaluate.eval(output);					// the postfix expression for evaluation
	    System.out.println("Output:" + op);				// Outputs the result 
	        
	 }		
}	 



