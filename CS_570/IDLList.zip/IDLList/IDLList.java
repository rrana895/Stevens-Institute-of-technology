// Name: Rachi Rana
// CWID: 10455300

package assignment_3;

import java.util.*;
import java.util.ArrayList;

public class IDLList<E> {
	
	// inner class
	private static class Node<E>{
		private E data;			// data fields
		private Node<E> next;
		private Node<E> prev;
		
		private Node(E elem) {
			data = elem;
			next = null;
			prev = null;
		}
		private Node(E elem, Node<E> prev, Node<E> next) {
			data = elem;
			this.next = next;
			this.prev = prev;
		}
	}
	
	
	private Node<E> head; // data fields IDLList
	private Node<E> tail;
	private int size;
	private ArrayList<Node<E>> indices;
	
	public IDLList(){ // that creates an empty double-linked list
		size = 0;
		head = null;
		tail = null;
		indices = new ArrayList<Node<E>>();
	}
	
	public boolean add(int index, E elem) { // that adds elem at position index
		if( index == 0) {
			add(elem);
			return true;
		}
		else if(index <0 || index > size) {
			throw new IndexOutOfBoundsException();
		}
		else {
			Node<E> node = indices.get(index);
			Node<E> temp = new Node<E>(elem, node.prev, node);
			node.prev.next = temp;
			
			node.prev = temp;
			size++;
			indices.add(index,temp);
		}
		
		return true;

	}
	
	public boolean add(E elem) { // that adds elem at the head
		
		Node<E> node = new Node<E>(elem, null, head);
		
		if(head != null) {
			head.prev = node;
		}
		
		head = node;
		indices.add(0, node);
		size++;
		tail = indices.get(indices.size()- 1);
		return true;
	}
	
	public boolean append(E elem){ // that adds elem as the new last element of the list
		if(head == null)
		{
			add(elem);
			return true;
		}
		Node<E> node = new Node<E>(elem, tail, null);
		tail.next = node;
	
		indices.add(node);
		size++;
		tail = indices.get(indices.size() - 1);
		
		return true;
	}
	
	public E get(int index) { // that returns the object at position index from the head
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		return this.indices.get(index).data;
	}
	
	public E getHead() { // that returns the object at the head. 
		return head.data;
	}
	
	public E getLast() { // that returns the object at the tail
		return tail.data;
	}
	
	public int size() { // that returns the list size
		return size;
	}
	
	public E remove() { // that removes and returns the element at the head
		if(head == null) {
			throw new IllegalStateException();
		}	
			Node<E> Head = head;
			if(Head.next == null) {
				
				indices.remove(0);
				size--;
				head = null;
				tail = null;
				return Head.data;
			}
			head = Head.next;
			head.prev = null;
			indices.remove(0);
			size --;
			return Head.data;
		}
	
	public E removeLast() { // that removes and returns the element at the tail
		if(tail == null) {
			throw new IllegalStateException();
		}
		Node<E> Tail = tail; 
		if(Tail.prev == null) {
			return remove();
		}
		Tail.prev.next = null; //
		indices.remove(indices.size() -1);
		size--;
		if(size != 0)
			tail = indices.get(indices.size() - 1);
		return Tail.data;
	}
	
	public E removeAt(int index) { // that removes and returns the element at the index 
		if(index < 0 || index >= size) {
			throw new IllegalStateException("index " + index);
		}
		if (index == 0) { 
            return remove();
        }

        if (index == size - 1) { 
            return removeLast();
        }

        Node<E> node = indices.remove(index);
        node.prev.next = node.next;
        node.next.prev = node.prev;
        size--;
        return node.data;
	}
	
	public boolean remove(E elem) { // that removes the first occurrence of elem in the list and returns true
		for(int i =0; i< indices.size(); i++)
		{
			if(indices.get(i).data == elem)
			{
				removeAt(i);
				return true;
				
			}
		}
		return false;
	}
	
	public String toString() { // that presents a string representation of the list
		Node<E> nodeRef = head;
		StringBuilder result = new StringBuilder();
		while (nodeRef != null) {
			result.append(nodeRef.data);
			if (nodeRef.next != null) {
				result.append(" --> ");
			}
			nodeRef = nodeRef.next;
		}
		return result.toString();
	}

}
        
      