package assignment_3;

//import assignment_3.IDLList;

public class IDLListTest {

	public static void main(String[] args) {

	        IDLList<Integer> Double_LL = new IDLList<>();
	        for (int i = 0; i < 12; i++) {
	        	Double_LL.add(i);
	        }
	        System.out.println("Elem is::  " + Double_LL);

	        System.out.println("After remove is: " + Double_LL.remove(5));
            System.out.println(Double_LL);
            System.out.println("After remove is: " + Double_LL.remove(9));
            System.out.println(Double_LL);

            System.out.println("The removed head elem: " + Double_LL.remove());
            System.out.println(Double_LL);

            int newIndex = Double_LL.size() - 1;
            Double_LL.add(newIndex, 100);
            System.out.println("Added is " + Double_LL.get(newIndex));
            System.out.println(Double_LL);
            System.out.println("Size is " + Double_LL.size());

            //System.out.println("Out of bounds: " + Double_LL.get(13)); Shows IndexOutOfBounds as expected

            Double_LL.append(111);
            System.out.println("Appended is " + Double_LL.get(Double_LL.size() - 1));
            System.out.println(Double_LL);


            System.out.println("Head is: " + Double_LL.getHead());
            System.out.println("Tail is: " + Double_LL.getLast());

            int del = Double_LL.size();
            for (int i = del - 1; i >= 0; i--) {
                System.out.println("Deleted is " + Double_LL.removeAt(i));
                System.out.println(Double_LL + "\n");
            }

            System.out.println("After all deleted empty " + Double_LL + "\n");


            Double_LL.add(0, 18);
            System.out.println("Added new elem " +Double_LL + "\n");

            Double_LL.append(51);
            System.out.println("Appended new elem " +Double_LL + "\n");

            Double_LL.append(11);
            System.out.println("Appended new elem " +Double_LL + "\n");

            System.out.println("Elem  " + Double_LL.getLast());

            System.out.println("Elem at  " + Double_LL.get(1));
            System.out.println("Elem at " + Double_LL.getHead());

            Double_LL.remove(51);
            System.out.println(Double_LL + "\n");
	   }
}


