#### Knowledge Discovery and Data Mining (CS 513A)####

# Course  : CS 513 - A
# First Name : Rachi
# Last Name : Rana
#Id : 10455300
# Purpose : Assignment 08: Ann

####### *************************************************** ########


rm(list = ls())

BCD<- read.csv("~/Desktop/wisc_bc_ContinuousVar.csv" ,na.strings = "?")

# View Breast cancer data file
View(BCD)

# internal structure of BCD
str(BCD)

rawData <- BCD[-1]
diagnosis <- as.factor(rawData$diagnosis)
diagnosis <- data.frame(diagnosis)
rawData <- cbind(data.frame(diagnosis), rawData[-1])



collumnNames <- names(rawData)

rawData[rawData$diagnosis=="M","Output"]<- 1 
rawData[rawData$diagnosis=="B","Output"]<- 0 

nnFormula <- as.formula(paste("Output~", paste(collumnNames[!collumnNames %in% "diagnosis"], collapse = " + ")))

# Implement a neural network model, with 5 hidden nodes, to classify diagnosis
nn <- neuralnet::neuralnet(nnFormula,data = rawData, hidden = 5, err.fct="ce", linear.output=FALSE, likelihood=TRUE)
plot(nn)
