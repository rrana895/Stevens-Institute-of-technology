#### Knowledge Discovery and Data Mining (CS 513A)####

# Course  : CS 513 - A
# First Name : Rachi
# Last Name : Rana
#Id : 10455300
# Purpose : Assignment 07: RF breast-cancer-wisconsin.data

####### *************************************************** ########


rm(list = ls())

BCD <- read.csv("~/Desktop/R csv/breast-cancer-wisconsin.data.csv",na.strings = "?")

# View Breast cancer data file
View(BCD)

# internal structure of BCD
str(BCD)

# convert all the integer data types to factor data type
BCD[sapply(BCD, is.integer)] <- lapply(BCD[sapply(BCD, is.integer)],as.factor)

# verify the internal structure of BCD again
str(BCD)

# set random seed
set.seed(1234)

# create test and training data sets removing the first coloumn which is id ID of samples
index<-sort(sample(nrow(BCD),round(.25*nrow(BCD))))
training<-BCD[-index,c(-1)]
test<-BCD[index,c(-1)]

# import random forest library
library(randomForest)

# random forest classification
fit <- randomForest( Class~., data=training, importance=TRUE, ntree=1000,na.action = na.omit)
importance(fit)
varImpPlot(fit)
Prediction <- predict(fit, test)
table(actual=test[,10],Prediction)

P#rediction
#actual   2   4
#2 112   2
#4   0  56

wrong<- (test[,10]!=Prediction )
errorRate<-sum(wrong,na.rm = TRUE)/length(wrong)
errorRate 
#0.01142857
accuracy <- 1-errorRate
accuracy
#0.9885714

BCD<- na.omit(BCD)
library(caret)
features <- BCD[-11][-1]
labels <- BCD[,11]

rf <- randomForest::randomForest(features, as.factor(labels))
plot(rf)

randomForest::varImpPlot(rf)

#install.packages('caret', dependencies = TRUE)

library(caret)

#Print All impo
imp <- caret::varImp(rf)
varImpPlot(rf)
## Print All Feature Importance
imp[order(imp$Overall, decreasing = TRUE), ,drop = FALSE]
## Print Major 3 Feature Importance
head(imp[order(imp$Overall, decreasing = TRUE), ,drop = FALSE],n = 3)

##Overall
#F2 78.16403
#F3 77.92440
#F6 53.34930

## The importance plot, we can conclude that F2, F6 and F3 are the top 3 important features of the data set. 



