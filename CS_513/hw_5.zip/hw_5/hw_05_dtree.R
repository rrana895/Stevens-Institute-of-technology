#### Knowledge Discovery and Data Mining (CS 513A)####
# Assignment 2 -breast-cancer-wisconsin.data #

# Course  : CS 513 - A
# First Name : Rachi
# Last Name : Rana
#Id : 10455300
# Purpose : Assignment 5 dtree

####### *************************************************** ########
rm(list = ls())

library(rpart)
?install.packages("rpart.plot")
library(rpart.plot)

BCD <- read.csv("~/Desktop/R csv/breast-cancer-wisconsin.data.csv",na.strings = "?")
View(BCD)


# convert all the integer data types to factor data type.
BCD[sapply(BCD, is.integer)] <- lapply(BCD[sapply(BCD, is.integer)],as.factor)

# verify the internal structure of BCD again
str(BCD)

# set random seed
set.seed(1234)
# create test and training data sets removing the first coloumn which is id ID of samples
index<-sort(sample(nrow(BCD),round(.25*nrow(BCD))))
training<-BCD[-index,c(-1)]
test<-BCD[index,c(-1)]

d1 <- rpart(Class ~ ., data =training, method = "anova")
d1
rpart.plot(d1, type=3, digits = 3, fallen.leaves = TRUE)
