#### Knowledge Discovery and Data Mining (CS 513A)####

# Course  : CS 513 - A
# First Name : Rachi
# Last Name : Rana
#Id : 10455300
# Purpose : final term question 4

####### *************************************************** ########

rm(list=ls())

IBMdata <-
  read.csv(file = "~/Desktop/IBM_Attrition_v3.csv",
           na.strings = "NA")

# Delete rows with missing values
IBMdata <- na.omit(IBMdata)

# Select every third record, starting with the first record, 
# as the test dataset and the remaining records as the training dataset
idx <- seq(1,nrow(IBMdata),by=3)
training <- IBMdata[-idx,]
test <- IBMdata[idx,]

# Perform Random Forest classification for the ??attrition?? column  
# Score the test dataset
# Measure the error rate. 
library(randomForest)
set.seed(123)
fit <- randomForest(factor(Attrition)~.,data=training,ntree=1000)
IBM_predict <- predict(fit,test)
error_rate <- sum(IBM_predict!=test$price)/length(IBM_predict)
error_rate
# error_rate
# [1] 0