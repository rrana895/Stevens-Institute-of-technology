#### Knowledge Discovery and Data Mining (CS 513A)####

# Course  : CS 513 - A
# First Name : Rachi
# Last Name : Rana
#Id : 10455300
# Purpose : final term question 5 and 6

####### *************************************************** ########

# Using hclust, categorize the ??IBM_Attrition_v3.csv?? data into two (2) clusters using all the columns 
# except the ??Attrition?? and ??MaritalStatus?? columns. 
# Tabulate the clustered rows against the ??Attrition?? column. 
# (Remove the rows with missing values first)  
# clearing object enviroment 

rm(list=ls())

IBMdata <-
  read.csv(file = "~/Desktop/IBM_Attrition_v3.csv",
           na.strings = "NA")


# Delete rows with missing values
IBMdata <- na.omit(IBMdata)

mmnorm <-function(x,minx,maxx) {z<-((x-minx)/(maxx-minx))
return(z) 
}

IBM_normalized <- as.data.frame (         
  cbind( Age=mmnorm(IBMdata$Age,min(IBMdata$Age),max(IBMdata$Age)),
         JobSatisfaction=mmnorm(IBMdata$JobSatisfaction,min(IBMdata$JobSatisfaction),max(IBMdata$JobSatisfaction)),
         MonthlyIncome=mmnorm(IBMdata$MonthlyIncome,min(IBMdata$MonthlyIncome),max(IBMdata$MonthlyIncome)),
         YearsAtCompany=mmnorm(IBMdata$YearsAtCompany,min(IBMdata$YearsAtCompany),max(IBMdata$YearsAtCompany)),
         Attrition=factor(IBMdata$Attrition)
  )
)

## Hclust 
IBM_normalized_dist <- dist(IBM_normalized[,c(-6)])
hclust_results <- hclust(IBM_normalized_dist,method ="average" )
hclust_2 <- cutree(hclust_results,2)
table(Hclust=hclust_2,Actual=IBM_normalized[,5])
#         Actual
# Hclust   1    2
#      1 108   25
#      2   0    1
plot(hclust_results, cex = 0.6, hang = -1)



## K-means 
kmeans_result<- kmeans(IBM_normalized[,c(-6)],2,nstart = 10)
table(kmeans=kmeans_result$cluster,Actual=IBM_normalized[,5])
#       Actual
# kmeans   1   2
#      1 108   0
#      2   0  26
library(fpc)
plotcluster(IBM_normalized_dist, kmeans_result$cluster)
