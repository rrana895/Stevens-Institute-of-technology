f = open('/Users/rachirana/Desktop/Gedcom/Project_1.ged', 'r')
output = open('output_ged.txt', 'w')

for line in f:
    print('--> %s' % line[:-1])
    output.write('--> %s \n' % line[:-1])
    arr = line.split()
    if 'INDI' in arr[-1] or 'FAM' in arr[-1]:
        arr[-1], arr[-2] = arr[-2], arr[-1]  # swap
        arr.insert(2, 'Y')
        out = '<-- ' + "|".join(arr)
        print(out)
        output.write(out + '\n')
        continue
    tags = ['INDI', 'NAME', 'SEX', 'BIRT', 'DEAT', 'FAMC', 'FAMS', 'FAM', 'MARR', 'HUSB', 'WIFE',
            'CHIL', 'DIV', 'DATE', 'HEAD', 'TRLR', 'NOTE']
    if any(x in arr for x in tags):
        arr.insert(2, 'Y')
        out = '<-- ' + "|".join(arr)
        print(out)
        output.write(out + '\n')
        continue
    else:
        arr.insert(2, 'N')
        out = '<-- ' + "|".join(arr)
        print(out)
        output.write(out + '\n')
f.close()
output.close()
