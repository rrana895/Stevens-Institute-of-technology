Just double-click the "run" file, which should: create a node_modules folder, install the dependencies, open your browser, and start an express server
