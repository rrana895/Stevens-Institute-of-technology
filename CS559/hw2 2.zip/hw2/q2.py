import numpy as np
import pandas as pd
import math
from numpy.random import RandomState


def MLE(c, w):
    df = pd.read_csv("pima-indians-diabetes.csv")
    df = df.drop(columns=['x1', 'x5', 'x6', 'x7', 'x8'])
    rng = RandomState()

    train = df.sample(frac=0.5, random_state=rng)
    test = df.loc[~df.index.isin(train.index)]

    train0 = train[train['y'] == 0]
    train1 = train[train['y'] == 1]

    mean0 = train0.mean(axis=0)
    var0 = train0.var(axis=0)
    mean1 = train1.mean(axis=0)
    var1 = train1.var(axis=0)

    prior0 = len(train0)
    prior1 = len(train1)

    for i, row in test.iterrows():
        likelihood0 = ((1.0 / (math.sqrt(2 * 3.1415 * var0['x2']))) * math.exp((-0.5) * ((row['x2'] - mean0['x2'])**2) / var0['x2'])) * ((1.0 / (math.sqrt(2 * 3.1415 * var0['x3']))) * math.exp(
            (-0.5) * ((row['x3'] - mean0['x3'])**2) / var0['x3'])) * ((1.0 / (math.sqrt(2 * 3.1415 * var0['x4']))) * math.exp((-0.5) * ((row['x4'] - mean0['x4'])**2) / var0['x4']))
        likelihood1 = ((1.0 / (math.sqrt(2 * 3.1415 * var1['x2']))) * math.exp((-0.5) * ((row['x2'] - mean1['x2'])**2) / var1['x2'])) * ((1.0 / (math.sqrt(2 * 3.1415 * var1['x3']))) * math.exp(
            (-0.5) * ((row['x3'] - mean1['x3'])**2) / var1['x3'])) * ((1.0 / (math.sqrt(2 * 3.1415 * var1['x4']))) * math.exp((-0.5) * ((row['x4'] - mean1['x4'])**2) / var1['x4']))
        posterior0 = prior0 * likelihood0
        posterior1 = prior1 * likelihood1

        if(posterior0 > posterior1 and row['y'] == 0):
            c += 1
        elif(posterior0 < posterior1 and row['y'] == 1):
            c += 1
        else:
            w += 1
    return(c, w)


list = []
mean = 0
for i in range(10):
    c = 0
    w = 0
    c, w = MLE(c, w)
    list.append(float(c) / (c + w) * 100)
mean = np.average(list)
sd = np.std(list)
print("Mean=", mean)
print("Standard Deviation=", sd)
