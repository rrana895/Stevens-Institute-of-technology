import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix


def SplitData():
    df = pd.read_csv("pima-indians-diabetes.csv")
    df = df.drop(columns=['x1', 'x5', 'x6', 'x7', 'x8'])
    X = df.drop(columns=['y']).values.tolist()
    y = df.drop(columns=['x2', 'x3', 'x4']).values.reshape(-1).tolist()
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.50)
    return (X_tr, X_te, y_tr, y_te)


def KNNClassifier(X_tr, X_te, y_tr, y_te, k):
    classifier = KNeighborsClassifier(n_neighbors=k)
    classifier.fit(X_tr, y_tr)
    y_pr = classifier.predict(X_te)
    return(y_pr)


def findAccuracy(y_te, y_pr):
    c = 0
    w = 0
    for m in range(len(y_pr)):
        if(y_te[m] == y_pr[m]):
            c += 1
        else:
            w += 1
    return(c, w)


list = []
for K in [1, 5, 11]:
    for i in range(10):
        X_tr, X_te, y_tr, y_te = SplitData()
        y_pr = KNNClassifier(X_tr, X_te, y_tr, y_te, K)
        c, w = findAccuracy(y_te, y_pr)
        list.append(float(c) / (c + w) * 100)
        mean = np.average(list)
        sd = np.std(list)
    print("\nK=", K, "\nMean=", mean, "Standard Deviation=", sd)
