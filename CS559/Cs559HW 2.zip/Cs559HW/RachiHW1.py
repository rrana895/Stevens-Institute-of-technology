import numpy as np

def Generator(mean, var, N):
    X=np.random.normal(mean, np.sqrt(var), N)
    while ( not (abs(np.mean(X)-mean) <= 0.01 and abs(np.var(X)-var) <= 0.01 )):
        X=np.random.normal(mean, np.sqrt(var), N)
        continue
    print(X)
    print("Given Mean=", mean, "\t Estimated mean:", np.mean(X))
    print("Given variance:", var, "\t Estimated variance", np.var(X))

Generator(2,7,100)
